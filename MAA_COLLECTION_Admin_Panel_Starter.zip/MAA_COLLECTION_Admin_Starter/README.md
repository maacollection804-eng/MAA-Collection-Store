# MAA COLLECTION Admin Panel Starter

This is a Cloudflare Pages starter with server-side admin login, product management, phone photo uploads to R2, and a public product catalogue.

## Owner setup required
1. Create Cloudflare D1 database `maa-collection-db`; run `schema.sql` in its console.
2. Create Cloudflare R2 bucket `maa-collection-images`.
3. In Pages > Settings > Functions, bind D1 as `DB` and R2 as `IMAGES`.
4. Add secrets: `ADMIN_USERNAME`, `ADMIN_PASSWORD` (unique, long), `SESSION_SECRET` (random 32+ characters). Add variables `SITE_ORIGIN=https://maa-collection-store.pages.dev` and `PUBLIC_IMAGE_BASE=https://YOUR-R2-CUSTOM-DOMAIN` (configure an R2 custom domain; do not use a guessed URL).
5. Pages build settings: preset None, build command blank, output directory `public`.
6. Put this package's contents in the root of the GitHub repo connected to Pages, then redeploy.
7. Test `/api/health`, then visit `/admin.html`.

Never share passwords in chat or place them in browser code. The adult shop owner should own Cloudflare resources and payment accounts.

## Included
- `/admin.html`: login; add/edit/delete products; upload JPG/PNG/WebP from phone (max 5 MB).
- `/`: public catalogue reads products from D1.
- `schema.sql`: products table and sample entries.

## Not included yet
WhatsApp orders are only sent as messages; this starter does not save orders or include an order-management screen. It does not process or verify COD/JazzCash/Easypaisa payments. Google ranking cannot be guaranteed; add and verify the domain in Google Search Console and submit a sitemap after launch.

Check all shop details and the WhatsApp number before publishing.
