const enc=new TextEncoder(), COOKIE="maa_admin_session", AGE=28800;
function b64(b){let s="";for(const x of b)s+=String.fromCharCode(x);return btoa(s).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/g,"")}
function un64(s){s=s.replace(/-/g,"+").replace(/_/g,"/");while(s.length%4)s+="=";return Uint8Array.from(atob(s),c=>c.charCodeAt(0))}
async function sign(secret,msg){const k=await crypto.subtle.importKey("raw",enc.encode(secret),{name:"HMAC",hash:"SHA-256"},false,["sign"]);return new Uint8Array(await crypto.subtle.sign("HMAC",k,enc.encode(msg)))}
export async function makeSession(env){const p=b64(enc.encode(JSON.stringify({u:env.ADMIN_USERNAME,exp:Date.now()+AGE*1000})));return p+"."+b64(await sign(env.SESSION_SECRET,p))}
export async function requireAdmin(req,env){if(!env.SESSION_SECRET)return false;const c=(req.headers.get("Cookie")||"").split(";").map(x=>x.trim()).find(x=>x.startsWith(COOKIE+"="));if(!c)return false;const a=c.slice(COOKIE.length+1).split(".");if(a.length!==2)return false;let expected=await sign(env.SESSION_SECRET,a[0]),got;try{got=un64(a[1])}catch{return false}if(got.length!==expected.length)return false;let d=0;for(let i=0;i<got.length;i++)d|=got[i]^expected[i];if(d)return false;try{const v=JSON.parse(new TextDecoder().decode(un64(a[0])));return v.u===env.ADMIN_USERNAME&&v.exp>Date.now()}catch{return false}}
export const cookie=t=>`${COOKIE}=${t}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=${AGE}`;
export const clear=()=>`${COOKIE}=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0`;
export const originOK=(req,env)=>!!req.headers.get("Origin")&&req.headers.get("Origin")===env.SITE_ORIGIN;
