import {clear,originOK} from "../_lib/auth.js";
export async function onRequestPost({request,env}){if(!originOK(request,env))return Response.json({error:"Origin rejected"},{status:403});return Response.json({ok:true},{headers:{"Set-Cookie":clear(),"Cache-Control":"no-store"}})}
