CREATE TABLE IF NOT EXISTS products (
 id TEXT PRIMARY KEY, name TEXT NOT NULL, category TEXT NOT NULL CHECK(category IN ('Casual','Fancy')),
 price INTEGER NOT NULL CHECK(price>=0), sizes TEXT NOT NULL DEFAULT '["S","M","L","XL"]',
 image_url TEXT NOT NULL, tag TEXT NOT NULL DEFAULT 'New Arrival', active INTEGER NOT NULL DEFAULT 1,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_products_active ON products(active,created_at);
INSERT OR IGNORE INTO products(id,name,category,price,sizes,image_url,tag,active) VALUES
('sample-casual','Everyday Printed Suit','Casual',1500,'["S","M","L","XL"]','https://placehold.co/700x900?text=Upload+your+photo','Sample',1),
('sample-fancy','Elegant Fancy Suit','Fancy',2500,'["S","M","L","XL"]','https://placehold.co/700x900?text=Upload+your+photo','Sample',1);
